#include<stdio.h>

void main()
{
	int a,b;
	char d;
	a=3;
	c=a+d;
}

